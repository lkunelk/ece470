%% Creates a line from y = -100 to y = 100 using 100 points at a given coordinate
%% z stays at -2 due to the offset we defined
function line = mysegment(xcoord)
    ycoord = linspace(-100,100,100);
    zcoord = linspace(-2,-2,100);
    line = [xcoord ; ycoord; zcoord]

