function result = eight()
    %% Creates the eight function which first takes in the theta variable
    %% Then using that creates a circle of radius 20 at (610,0)
    %% Finally, uses the theta to append at centre (650,0) with radius 20
    %% This helps it create a vector of points with 2 circles joined together

    theta = linspace(0,2*pi,100)
    xcoord  = 610 + 20*cos(theta)
    ycoord  = 20*sin(theta);
    xcoord2 = 650 + 20*cos(theta);
    zcoord = linspace(-2,-2,100);
    line1  = [xcoord ; ycoord; zcoord]
    line2 = [xcoord2;ycoord; zcoord]
    result = [line1 , line2];
