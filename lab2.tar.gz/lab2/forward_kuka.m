%% Used fkine in this case as well we had in part 1. We did change inverse becuase the TA instructed us to.

function H = forward_kuka(joint, robot)
    % joint - 1xn matrix, joint values
    % robot - SerialLink

    H = robot.fkine(joint);
end
