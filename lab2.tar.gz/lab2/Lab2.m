%% define variables
a1 = 25; % [mm]
a2 = 315;
a3 = 35;
a6 = 296.23;
d1 = 400;
d4 = 365;
d6 = 161.44;

% Defining the KUKA robot
DH = [
    [0, d1, a1, pi/2 ]
    [0,  0, a2, 0    ]
    [0,  0, a3, pi/2 ]
    [0, d4,  0,-pi/2 ]
    [0,  0,  0, pi/2 ]
    [0, d6, -a6, 0   ]
];

kuka = mykuka(DH);
kuka_wrist = mykuka(DH(1:4,:))

% Plot KUKA robot with initial angles to be set to [0,0,0,0,0,0]
plot(kuka, [0 0 0 0 0 0])

%% test model with different q values
n = 100;
start_q = [0 pi/2 0 0 0 pi/2 0];
desir_q = [pi/5 pi/3 -pi/4 pi/4 pi/3 pi/4];

qs = zeros(n, 6);
for i=1:6
    qs(:, i) = linspace(start_q(i), desir_q(i), n)';
end

H = forward_kuka(qs, kuka);
plot(kuka, qs);

%% inverse
%H = [0 0 1 500; 0 -1 0 0; 1 0 0 0; 0 0 0 1]
%H_d = SE3.check(H)
q = inverse_kuka(H, kuka);
desir_q
q'

%%
getAngles()
moveAxis()

%% Calibrate angles using the joystick
x1 = [624.80; 114.96; 27.24]
q1 = [0.2229    0.7639   -0.2211    0.2580    1.0505   -0.1311]

x2 = [628.84; -146.32; 28.82]
q2 =  [-0.3339; 0.7376; -0.1930; -0.3742; 1.1095 ;0.1890]

x3 = [484.14; -4.13; 28.83]
q3 = [-0.0463; 1.0081; -0.7894; -0.0466; 1.4034; 0.0084]

%% find a delta so that the pencil can adjust to the paper
delta = fminunc(@deltajoint,[0 0])
myrobot = mykuka_search(delta)

%% Let's take it back to the initial position and set the angles
%% which would take the robot to the position and rotation
%% according to the H matrix

%% Change the z ourselves manually by 2 due to offset issue
setHome(0.04)
H = [0 0 1 621.67 ; 0 -1 0 114.96 ; 1 0 0 25 ; 0 0 0 1]
q = inverse_kuka(H,myrobot)
setAngles(q, 0.04)

%% Do the frame transformation of workspace to the baseframe
p_workspace = [600; 100; 10];
p_baseframe = FrameTransformation(p_workspace)

R = [0 0 1; 0 -1 0; 1 0 0]
H = [R p_baseframe; zeros(1,3) 1]
q = inverse_kuka(H, myrobot)
setAngles(q, 0.04)

%% Developing a line at x = 600 using 100 points

xcoord = linspace(600,600,100);
line = mysegment(xcoord);
R = [0 0 1 ; 0 -1 0; 1 0 0];
H = zeros(4,4);
q = zeros(100,6);
for i = 1:100
    p_baseframe = FrameTransformation(line(:,i))
    H = [R p_baseframe ; 0 0 0 1];
    q(i,:) = inverse_kuka(H, myrobot);
    setAngles(q(i,:),0.04)
end
%plot(myrobot,q)

%% Bring it back up
setHome(0.04)
%% Plotting the circle with centre = (620,0) and radius = 50

circle = mycircle();
R = [0 0 1 ; 0 -1 0; 1 0 0];
H = zeros(4,4);
q = zeros(100,6);
for i = 1:100
    p_baseframe = FrameTransformation(circle(:,i))
    H = [R p_baseframe ; 0 0 0 1];
    q(i,:) = inverse_kuka(H, myrobot);
    setAngles(q(i,:),0.04)
end

%% Read the data from the jug.xlsx to create a jug figure
%% We chose point to be (550,0) as the starting point
data = xlsread('jug.xlsx')
xdata = 550 + 10*data(:,1)
ydata = 10*data(:,2);
zdata = 2*(-ones(length(data),1));
R = [0 0 1 ; 0 -1 0; 1 0 0];
H = zeros(4,4);
q = zeros(100,6);
for i = 1:100
    p_baseframe = FrameTransformation([xdata(i);ydata(i);zdata(i)])
    H = [R p_baseframe ; 0 0 0 1];
    q(i,:) = inverse_kuka(H, myrobot);
    setAngles(q(i,:),0.04)
end

%% Create an Eight figure using 2 circles. The only difference
%% is that the way it is appended it creates a semicircle and
%% then other semicircle
myeight = eight()
R = [0 0 1 ; 0 -1 0; 1 0 0];
H = zeros(4,4);
q = zeros(200,6);
for i = 1:200
    p_baseframe = FrameTransformation(myeight(:,i));
    H = [R p_baseframe ; 0 0 0 1];
    q(i,:) = inverse_kuka(H, myrobot);
    setAngles(q(i,:),0.04)
end
